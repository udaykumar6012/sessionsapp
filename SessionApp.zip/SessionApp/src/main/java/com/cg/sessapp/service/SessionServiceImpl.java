package com.cg.sessapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sessapp.bean.SessionApp;
import com.cg.sessapp.dao.SessionDao;
import com.cg.sessapp.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService {
	
	@Autowired
    SessionDao sessionDao;
	
	@Override
	public List<SessionApp> addSession(SessionApp session) throws SessionException {
		// TODO Auto-generated method stub
		try {
			 sessionDao.save(session);
			return sessionDao.findAll();
		}
		catch (Exception ex) {
			// TODO: handle exception
			throw new SessionException(ex.getMessage());
		}
	
	}

	@Override
	public SessionApp updateSession(Integer sessionId,SessionApp session) throws SessionException {
		// TODO Auto-generated method stub
		try {
			Optional<SessionApp> optional = sessionDao.findById(sessionId);
			if(optional.isPresent()) {
				SessionApp session1=sessionDao.findById(sessionId).get();
				session1.setDuration(session.getDuration());
				session1.setFacultyName(session.getFacultyName());
				return sessionDao.save(session);
			}
			else
				throw new SessionException("Session with ID " + sessionId + "does not exist.");
		} catch (Exception ex) {
			throw new SessionException(ex.getMessage());
		}
	}

	@Override
	public void deleteSession(Integer sessionId) throws SessionException {
		// TODO Auto-generated method stub
		try {
		     sessionDao.deleteById(sessionId);
			}
			catch (Exception ex) {
				// TODO: handle exception
				throw new SessionException(ex.getMessage());
			}
	}

	@Override
	public List<SessionApp> getAllSessions() throws SessionException {
		// TODO Auto-generated method stub
		try{
			return sessionDao.findAll();
			}
		catch (Exception ex) {
			// TODO: handle exception
			throw new SessionException(ex.getMessage());
		}
	}
	@Override
	public SessionApp getSessionById(int sessionId) throws SessionException {
		// TODO Auto-generated method stub
		try {
			return sessionDao.findById(sessionId).get();
			}
			catch (Exception ex) {
				// TODO: handle exception
				throw new SessionException(ex.getMessage());
			}
	}



}
