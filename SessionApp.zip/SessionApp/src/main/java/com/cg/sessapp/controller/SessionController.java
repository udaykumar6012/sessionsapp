package com.cg.sessapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sessapp.bean.SessionApp;
import com.cg.sessapp.exception.SessionException;
import com.cg.sessapp.service.SessionService;


@RestController
public class SessionController {
	@Autowired
	SessionService sessionService;
	
	@RequestMapping("/session")
	public List<SessionApp> getAllSessions() throws SessionException {
		return  sessionService.getAllSessions();
	}
	
	@RequestMapping(value = "/session", method = RequestMethod.POST)
	public List<SessionApp> addSession(@RequestBody SessionApp session) throws SessionException {
		return  sessionService.addSession(session);
	}
	@RequestMapping("/session/{sessionId}")
	public SessionApp getSessionById(@PathVariable int sessionId) throws SessionException 
	{
			return sessionService.getSessionById(sessionId);
	}

	
	
	@RequestMapping(value = "/session/{sessionId}", method = RequestMethod.PUT)
	public SessionApp updateSession(@PathVariable Integer sessionId,@RequestBody SessionApp session) throws SessionException {
		return  sessionService.updateSession(sessionId,session);
	}
	
	@RequestMapping(value = "/session/{sid}", method = RequestMethod.DELETE)
	public String deleteSession(@PathVariable("sid") Integer sessionId) throws SessionException {
		sessionService.deleteSession(sessionId);
		return  sessionId+" is deleted";
	}
	@ExceptionHandler({SessionException.class})
	public ResponseEntity<String> handleErrors()
	{
		
		return new ResponseEntity<String>("An error occured",HttpStatus.CONFLICT);
		
   }

}
