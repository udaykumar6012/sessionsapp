package com.cg.sessapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.sessapp.bean.SessionApp;

@Repository
public interface SessionDao extends JpaRepository<SessionApp, Integer>{

}
