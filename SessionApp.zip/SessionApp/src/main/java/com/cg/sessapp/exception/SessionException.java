package com.cg.sessapp.exception;

public class SessionException extends Exception {
	
	public SessionException() {
		
	}
	public SessionException(String msg)
	{
		super(msg);
	}

}
