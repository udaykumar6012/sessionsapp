package com.cg.sessapp.service;

import java.util.List;

import com.cg.sessapp.bean.SessionApp;
import com.cg.sessapp.exception.SessionException;



public interface SessionService {
	List<SessionApp> addSession(SessionApp session) throws SessionException;
	SessionApp updateSession(Integer sessionId,SessionApp session) throws SessionException;
	void deleteSession(Integer sessionId) throws SessionException;
	List<SessionApp> getAllSessions() throws SessionException;
	SessionApp getSessionById(int sessionId) throws SessionException;

}
