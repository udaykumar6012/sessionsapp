package com.cg.sessapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

@Entity
/* @Table(name="") */
public class SessionApp {
	
	@Id
	@GeneratedValue
	private Integer sessionId;
	private String sessionName;
	private String facultyName;
	@Min(3)
	@Max(10)
	private Integer duration;
	@Pattern(regexp = "(day|night)")
   // @Column(name="")
	private String modeOfSession;
	public Integer getSessionId() {
		return sessionId;
	}
	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getModeOfSession() {
		return modeOfSession;
	}
	public void setModeOfSession(String modeOfSession) {
		this.modeOfSession = modeOfSession;
	}
	

}
